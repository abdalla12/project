"""
Utility functions for the API.
"""
import torch
import torch.nn as nn
from typing import Literal
import sys
sys.path.append('../src')

from models import build_classification_model, build_detection_model


def load_model_for_inference(
    checkpoint_path: str,
    model_type: Literal["classification", "detection"],
    device: torch.device = torch.device("cpu")
) -> nn.Module:
    """
    Load model from checkpoint for inference.
    
    Args:
        checkpoint_path: Path to model checkpoint
        model_type: Type of model ('classification' or 'detection')
        device: Device to load model on
        
    Returns:
        Loaded model in eval mode
    """
    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # Build model
    if model_type == "classification":
        model = build_classification_model(
            model_name='resnet50',
            num_classes=2,
            pretrained=False
        )
    elif model_type == "detection":
        model = build_detection_model(
            num_classes=2,
            backbone_name='resnet50',
            pretrained_backbone=False
        )
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    
    # Load weights
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    
    return model


def preprocess_image(image, target_size=(224, 224)):
    """
    Preprocess image for model input.
    
    Args:
        image: PIL Image or numpy array
        target_size: Target size (height, width)
        
    Returns:
        Preprocessed tensor
    """
    # This is a placeholder - actual preprocessing done in API
    pass


def postprocess_detection(predictions, confidence_threshold=0.5):
    """
    Post-process detection predictions.
    
    Args:
        predictions: Model predictions
        confidence_threshold: Minimum confidence
        
    Returns:
        Filtered predictions
    """
    # This is a placeholder - actual post-processing done in API
    pass
