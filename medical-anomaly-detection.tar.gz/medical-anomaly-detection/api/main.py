"""
FastAPI application for medical image anomaly detection.
"""
import os
import io
from typing import List, Optional
import uuid
from pathlib import Path

import torch
import numpy as np
from PIL import Image
import cv2
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import albumentations as A
from albumentations.pytorch import ToTensorV2

from schemas import PredictionResponse, DetectionBox, HealthResponse
from utils import load_model_for_inference, preprocess_image, postprocess_detection


# Initialize FastAPI app
app = FastAPI(
    title="Medical Image Anomaly Detection API",
    description="API for pneumonia detection and localization in chest X-rays",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create directories
UPLOAD_DIR = Path("uploads")
RESULTS_DIR = Path("results")
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# Mount static files
app.mount("/results", StaticFiles(directory=str(RESULTS_DIR)), name="results")

# Global variables for models
CLASSIFICATION_MODEL = None
DETECTION_MODEL = None
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@app.on_event("startup")
async def startup_event():
    """Load models on startup."""
    global CLASSIFICATION_MODEL, DETECTION_MODEL
    
    print("Loading models...")
    
    # Load classification model
    cls_model_path = os.getenv("CLASSIFICATION_MODEL_PATH", "./models/best_model.pth")
    if os.path.exists(cls_model_path):
        CLASSIFICATION_MODEL = load_model_for_inference(
            cls_model_path,
            model_type="classification",
            device=DEVICE
        )
        print(f"✓ Classification model loaded from {cls_model_path}")
    else:
        print(f"⚠ Classification model not found at {cls_model_path}")
    
    # Load detection model
    det_model_path = os.getenv("DETECTION_MODEL_PATH", "./models/best_detection_model.pth")
    if os.path.exists(det_model_path):
        DETECTION_MODEL = load_model_for_inference(
            det_model_path,
            model_type="detection",
            device=DEVICE
        )
        print(f"✓ Detection model loaded from {det_model_path}")
    else:
        print(f"⚠ Detection model not found at {det_model_path}")
    
    print(f"Using device: {DEVICE}")


@app.get("/", response_class=JSONResponse)
async def root():
    """Root endpoint."""
    return {
        "message": "Medical Image Anomaly Detection API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "predict_classification": "/predict/classification",
            "predict_detection": "/predict/detection",
            "predict": "/predict (combines both)",
            "docs": "/docs"
        }
    }


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        classification_model_loaded=CLASSIFICATION_MODEL is not None,
        detection_model_loaded=DETECTION_MODEL is not None,
        device=str(DEVICE)
    )


@app.post("/predict/classification", response_model=PredictionResponse)
async def predict_classification(file: UploadFile = File(...)):
    """
    Classify chest X-ray as Normal or Pneumonia.
    
    Args:
        file: Uploaded image file
        
    Returns:
        Prediction with confidence score
    """
    if CLASSIFICATION_MODEL is None:
        raise HTTPException(status_code=503, detail="Classification model not loaded")
    
    try:
        # Read image
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        image_np = np.array(image)
        
        # Preprocess
        transform = A.Compose([
            A.Resize(224, 224),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2()
        ])
        
        transformed = transform(image=image_np)
        image_tensor = transformed['image'].unsqueeze(0).to(DEVICE)
        
        # Predict
        with torch.no_grad():
            outputs = CLASSIFICATION_MODEL(image_tensor)
            probs = torch.softmax(outputs, dim=1)
            pred_class = torch.argmax(probs, dim=1).item()
            confidence = probs[0, pred_class].item()
        
        # Map to class names
        class_names = ['Normal', 'Pneumonia']
        prediction = class_names[pred_class]
        
        return PredictionResponse(
            prediction=prediction,
            confidence=confidence,
            probabilities={
                'Normal': float(probs[0, 0]),
                'Pneumonia': float(probs[0, 1])
            }
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@app.post("/predict/detection")
async def predict_detection(
    file: UploadFile = File(...),
    confidence_threshold: float = 0.5
):
    """
    Detect and localize pneumonia regions with bounding boxes.
    
    Args:
        file: Uploaded image file
        confidence_threshold: Minimum confidence for detections
        
    Returns:
        Detections with bounding boxes and visualization URL
    """
    if DETECTION_MODEL is None:
        raise HTTPException(status_code=503, detail="Detection model not loaded")
    
    try:
        # Read image
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        image_np = np.array(image)
        orig_h, orig_w = image_np.shape[:2]
        
        # Preprocess
        transform = A.Compose([
            A.Resize(512, 512),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2()
        ])
        
        transformed = transform(image=image_np)
        image_tensor = transformed['image'].to(DEVICE)
        
        # Predict
        DETECTION_MODEL.eval()
        with torch.no_grad():
            predictions = DETECTION_MODEL([image_tensor])[0]
        
        # Process predictions
        boxes = predictions['boxes'].cpu().numpy()
        scores = predictions['scores'].cpu().numpy()
        labels = predictions['labels'].cpu().numpy()
        
        # Filter by confidence
        keep = scores >= confidence_threshold
        boxes = boxes[keep]
        scores = scores[keep]
        labels = labels[keep]
        
        # Scale boxes back to original image size
        scale_x = orig_w / 512
        scale_y = orig_h / 512
        boxes[:, [0, 2]] *= scale_x
        boxes[:, [1, 3]] *= scale_y
        
        # Create visualization
        vis_image = image_np.copy()
        for box, score, label in zip(boxes, scores, labels):
            if label == 1:  # Pneumonia
                x1, y1, x2, y2 = map(int, box)
                cv2.rectangle(vis_image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(
                    vis_image,
                    f'Pneumonia: {score:.2f}',
                    (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2
                )
        
        # Save visualization
        result_id = str(uuid.uuid4())
        result_path = RESULTS_DIR / f"{result_id}.png"
        cv2.imwrite(str(result_path), cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR))
        
        # Format response
        detection_boxes = [
            DetectionBox(
                xmin=float(box[0]),
                ymin=float(box[1]),
                xmax=float(box[2]),
                ymax=float(box[3]),
                confidence=float(score),
                label='Pneumonia' if label == 1 else 'Background'
            )
            for box, score, label in zip(boxes, scores, labels)
        ]
        
        return {
            "num_detections": len(detection_boxes),
            "boxes": detection_boxes,
            "visualization_url": f"/results/{result_id}.png"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Detection failed: {str(e)}")


@app.post("/predict")
async def predict_combined(
    file: UploadFile = File(...),
    confidence_threshold: float = 0.5
):
    """
    Combined endpoint: classification + detection.
    
    Args:
        file: Uploaded image file
        confidence_threshold: Minimum confidence for detections
        
    Returns:
        Classification result and detections
    """
    if CLASSIFICATION_MODEL is None or DETECTION_MODEL is None:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    try:
        # Get classification result
        classification_result = await predict_classification(file)
        
        # Get detection result
        await file.seek(0)  # Reset file pointer
        detection_result = await predict_detection(file, confidence_threshold)
        
        return {
            "classification": classification_result.dict(),
            "detection": detection_result
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Combined prediction failed: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
