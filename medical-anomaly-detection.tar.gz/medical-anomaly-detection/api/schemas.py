"""
Pydantic schemas for API request/response models.
"""
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class DetectionBox(BaseModel):
    """Bounding box for detection."""
    xmin: float = Field(..., description="Minimum x coordinate")
    ymin: float = Field(..., description="Minimum y coordinate")
    xmax: float = Field(..., description="Maximum x coordinate")
    ymax: float = Field(..., description="Maximum y coordinate")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Detection confidence")
    label: str = Field(..., description="Class label")


class PredictionResponse(BaseModel):
    """Response model for classification prediction."""
    prediction: str = Field(..., description="Predicted class (Normal/Pneumonia)")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Prediction confidence")
    probabilities: Dict[str, float] = Field(..., description="Class probabilities")


class DetectionResponse(BaseModel):
    """Response model for detection prediction."""
    num_detections: int = Field(..., description="Number of detections")
    boxes: List[DetectionBox] = Field(..., description="Detected bounding boxes")
    visualization_url: str = Field(..., description="URL to visualization image")


class CombinedResponse(BaseModel):
    """Response model for combined prediction."""
    classification: PredictionResponse
    detection: DetectionResponse


class HealthResponse(BaseModel):
    """Response model for health check."""
    status: str = Field(..., description="API status")
    classification_model_loaded: bool = Field(..., description="Classification model status")
    detection_model_loaded: bool = Field(..., description="Detection model status")
    device: str = Field(..., description="Device being used (cpu/cuda)")


class ErrorResponse(BaseModel):
    """Response model for errors."""
    detail: str = Field(..., description="Error message")
