# Implementation Guide - Medical Image Anomaly Detection

This guide provides step-by-step instructions for implementing and deploying the medical image anomaly detection system.

## Table of Contents
1. [Environment Setup](#environment-setup)
2. [Data Preparation](#data-preparation)
3. [Phase A: Classification](#phase-a-classification)
4. [Phase B: Detection](#phase-b-detection)
5. [Evaluation](#evaluation)
6. [API Deployment](#api-deployment)
7. [Troubleshooting](#troubleshooting)

---

## Environment Setup

### 1. Clone and Setup

```bash
# Clone repository
git clone https://github.com/yourusername/medical-anomaly-detection.git
cd medical-anomaly-detection

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install package
pip install -e .
```

### 2. Verify Installation

```python
import torch
import torchvision
import cv2
import albumentations

print(f"PyTorch: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
```

---

## Data Preparation

### 1. Download RSNA Dataset

```bash
# Install Kaggle API
pip install kaggle

# Setup Kaggle credentials (~/.kaggle/kaggle.json)
# Then download
kaggle competitions download -c rsna-pneumonia-detection-challenge

# Unzip
unzip rsna-pneumonia-detection-challenge.zip -d ./data/raw
```

### 2. Preprocess Data

```bash
python src/preprocess.py \
    --data_dir ./data/raw \
    --output_dir ./data/processed \
    --labels_csv ./data/raw/stage_2_train_labels.csv \
    --train_ratio 0.7 \
    --val_ratio 0.15 \
    --test_ratio 0.15
```

This will:
- Convert DICOM to PNG with lung windowing
- Split data into train/val/test (70/15/15)
- Save classification labels and detection annotations
- Create directory structure:
  ```
  data/processed/
  ├── train/
  ├── val/
  ├── test/
  ├── train.csv
  ├── val.csv
  ├── test.csv
  ├── train_boxes.csv
  ├── val_boxes.csv
  └── test_boxes.csv
  ```

### 3. Verify Data

```python
import pandas as pd

# Check splits
train_df = pd.read_csv('./data/processed/train.csv')
print(f"Train samples: {len(train_df)}")
print(f"Class distribution:\n{train_df['Target'].value_counts()}")
```

---

## Phase A: Classification

### 1. Configure Training

Edit `configs/classification.yaml`:
- Adjust batch size based on GPU memory
- Set `use_wandb: true` for experiment tracking
- Configure augmentation parameters

### 2. Start Training

```bash
# Basic training
python src/train.py \
    --config configs/classification.yaml \
    --phase classification

# With custom settings
python src/train.py \
    --config configs/classification.yaml \
    --phase classification \
    --epochs 50 \
    --batch_size 32
```

### 3. Monitor Training

If using Weights & Biases:
1. Sign up at https://wandb.ai
2. Login: `wandb login`
3. View dashboard at https://wandb.ai/your-username/medical-anomaly-detection

### 4. Expected Results

After ~30-40 epochs:
- Training Accuracy: 85-90%
- Validation AUC: 0.90-0.95
- Best model saved to `./experiments/classification/best_model.pth`

### 5. Troubleshooting

**CUDA Out of Memory:**
```yaml
# Reduce batch_size in config
training:
  batch_size: 16  # or 8
```

**Class Imbalance:**
```yaml
# Add class weights
training:
  class_weights: [0.4, 0.6]  # Adjust based on your data
```

---

## Phase B: Detection

### 1. Configure Training

Edit `configs/detection.yaml`:
- Start with smaller batch size (4 or 2)
- Detection requires more memory than classification

### 2. Start Training

```bash
python src/train.py \
    --config configs/detection.yaml \
    --phase detection
```

### 3. Expected Results

After ~20-30 epochs:
- mAP@0.5: 0.40-0.50
- Training converges slower than classification
- Best model saved to `./experiments/detection/best_detection_model.pth`

---

## Evaluation

### 1. Evaluate Classification Model

```bash
python src/eval.py \
    --config configs/classification.yaml \
    --model_path ./experiments/classification/best_model.pth \
    --output_dir ./experiments/evaluation
```

This generates:
- ROC curve (`roc_curve.png`)
- Precision-Recall curve (`pr_curve.png`)
- Confusion matrix (`confusion_matrix.png`)
- Metrics report (`metrics.yaml`)
- Error analysis (`errors.yaml`)

### 2. Inference on New Images

```bash
# Classification only
python src/infer.py \
    --image path/to/xray.png \
    --cls_model ./experiments/classification/best_model.pth \
    --device cuda

# Detection only
python src/infer.py \
    --image path/to/xray.png \
    --det_model ./experiments/detection/best_detection_model.pth \
    --output ./results/detection_result.png \
    --threshold 0.5 \
    --device cuda

# Both models
python src/infer.py \
    --image path/to/xray.png \
    --cls_model ./experiments/classification/best_model.pth \
    --det_model ./experiments/detection/best_detection_model.pth \
    --output ./results/combined_result.png \
    --device cuda
```

---

## API Deployment

### 1. Local Deployment

```bash
# Start API server
uvicorn api.main:app --reload --host 0.0.0.0 --port 8000

# Test health endpoint
curl http://localhost:8000/health
```

### 2. Docker Deployment

```bash
# Build image
docker build -t medical-anomaly-detection -f docker/Dockerfile .

# Run container
docker run -p 8000:8000 \
    -v $(pwd)/models:/app/models \
    medical-anomaly-detection

# Or use docker-compose
docker-compose -f docker/docker-compose.yml up
```

### 3. API Usage Examples

**Python:**
```python
import requests

# Upload image
url = "http://localhost:8000/predict"
files = {"file": open("chest_xray.png", "rb")}
response = requests.post(url, files=files)

result = response.json()
print(f"Prediction: {result['classification']['prediction']}")
print(f"Confidence: {result['classification']['confidence']:.2%}")
print(f"Detections: {result['detection']['num_detections']}")
```

**cURL:**
```bash
curl -X POST "http://localhost:8000/predict" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@chest_xray.png"
```

**Interactive Documentation:**
Visit http://localhost:8000/docs for Swagger UI

---

## Troubleshooting

### Common Issues

**1. Import Errors**
```bash
# Reinstall package in development mode
pip install -e .
```

**2. DICOM Reading Errors**
```python
# Check DICOM file
import pydicom
dcm = pydicom.dcmread('file.dcm')
print(dcm)
```

**3. Model Not Loading**
```python
# Check checkpoint
checkpoint = torch.load('model.pth', map_location='cpu')
print(checkpoint.keys())
```

**4. API Model Path Issues**
```bash
# Set environment variables
export CLASSIFICATION_MODEL_PATH=/absolute/path/to/best_model.pth
export DETECTION_MODEL_PATH=/absolute/path/to/best_detection_model.pth
```

### Performance Optimization

**1. Enable Mixed Precision Training**
```python
from torch.cuda.amp import autocast, GradScaler

scaler = GradScaler()
with autocast():
    outputs = model(images)
    loss = criterion(outputs, labels)
scaler.scale(loss).backward()
```

**2. Use Multiple GPUs**
```python
if torch.cuda.device_count() > 1:
    model = nn.DataParallel(model)
```

**3. Optimize DataLoader**
```yaml
data:
  num_workers: 4  # Increase for faster data loading
  pin_memory: true
```

---

## Next Steps

1. **Hyperparameter Tuning**: Use Optuna or Ray Tune
2. **Model Ensemble**: Combine multiple models
3. **Advanced Augmentation**: Add CutMix, MixUp
4. **Explainability**: Add Grad-CAM visualization
5. **Production**: Add monitoring, logging, A/B testing

---

## Additional Resources

- [RSNA Challenge](https://www.kaggle.com/c/rsna-pneumonia-detection-challenge)
- [PyTorch Documentation](https://pytorch.org/docs/)
- [Faster R-CNN Paper](https://arxiv.org/abs/1506.01497)
- [Medical AI Best Practices](https://arxiv.org/abs/1711.05225)

---

## Support

For issues and questions:
- GitHub Issues: [github.com/yourusername/medical-anomaly-detection/issues]
- Email: your.email@example.com
