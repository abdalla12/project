"""
Inference script for making predictions on new images.
"""
import os
import argparse
from pathlib import Path
from typing import List, Tuple
import numpy as np
import torch
from PIL import Image
import cv2
import albumentations as A
from albumentations.pytorch import ToTensorV2

from models import build_classification_model, build_detection_model, load_model
from visualize import visualize_detection


class MedicalImagePredictor:
    """Predictor for medical image analysis."""
    
    def __init__(
        self,
        classification_model_path: str = None,
        detection_model_path: str = None,
        device: str = 'cpu'
    ):
        """
        Initialize predictor.
        
        Args:
            classification_model_path: Path to classification model
            detection_model_path: Path to detection model
            device: Device to use ('cpu' or 'cuda')
        """
        self.device = torch.device(device)
        
        # Load classification model
        if classification_model_path and os.path.exists(classification_model_path):
            print(f"Loading classification model from {classification_model_path}")
            self.cls_model = build_classification_model(
                model_name='resnet50',
                num_classes=2,
                pretrained=False
            )
            self.cls_model = load_model(classification_model_path, self.cls_model, self.device)
            print("✓ Classification model loaded")
        else:
            self.cls_model = None
            print("⚠ Classification model not loaded")
        
        # Load detection model
        if detection_model_path and os.path.exists(detection_model_path):
            print(f"Loading detection model from {detection_model_path}")
            self.det_model = build_detection_model(
                num_classes=2,
                backbone_name='resnet50',
                pretrained_backbone=False
            )
            checkpoint = torch.load(detection_model_path, map_location=self.device)
            self.det_model.load_state_dict(checkpoint['model_state_dict'])
            self.det_model = self.det_model.to(self.device)
            self.det_model.eval()
            print("✓ Detection model loaded")
        else:
            self.det_model = None
            print("⚠ Detection model not loaded")
        
        # Transforms
        self.cls_transform = A.Compose([
            A.Resize(224, 224),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2()
        ])
        
        self.det_transform = A.Compose([
            A.Resize(512, 512),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2()
        ])
    
    def predict_classification(self, image_path: str) -> Tuple[str, float, dict]:
        """
        Predict classification.
        
        Args:
            image_path: Path to image
            
        Returns:
            prediction: Predicted class
            confidence: Confidence score
            probabilities: Dictionary of class probabilities
        """
        if self.cls_model is None:
            raise ValueError("Classification model not loaded")
        
        # Load image
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Preprocess
        transformed = self.cls_transform(image=image)
        image_tensor = transformed['image'].unsqueeze(0).to(self.device)
        
        # Predict
        with torch.no_grad():
            outputs = self.cls_model(image_tensor)
            probs = torch.softmax(outputs, dim=1)
            pred_class = torch.argmax(probs, dim=1).item()
            confidence = probs[0, pred_class].item()
        
        class_names = ['Normal', 'Pneumonia']
        prediction = class_names[pred_class]
        
        probabilities = {
            'Normal': float(probs[0, 0]),
            'Pneumonia': float(probs[0, 1])
        }
        
        return prediction, confidence, probabilities
    
    def predict_detection(
        self,
        image_path: str,
        confidence_threshold: float = 0.5,
        output_path: str = None
    ) -> List[dict]:
        """
        Predict detection with bounding boxes.
        
        Args:
            image_path: Path to image
            confidence_threshold: Minimum confidence for detections
            output_path: Optional path to save visualization
            
        Returns:
            List of detections with boxes and scores
        """
        if self.det_model is None:
            raise ValueError("Detection model not loaded")
        
        # Load image
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        orig_h, orig_w = image.shape[:2]
        
        # Preprocess
        transformed = self.det_transform(image=image)
        image_tensor = transformed['image'].to(self.device)
        
        # Predict
        with torch.no_grad():
            predictions = self.det_model([image_tensor])[0]
        
        # Process predictions
        boxes = predictions['boxes'].cpu().numpy()
        scores = predictions['scores'].cpu().numpy()
        labels = predictions['labels'].cpu().numpy()
        
        # Filter by confidence
        keep = scores >= confidence_threshold
        boxes = boxes[keep]
        scores = scores[keep]
        labels = labels[keep]
        
        # Scale boxes to original size
        scale_x = orig_w / 512
        scale_y = orig_h / 512
        boxes[:, [0, 2]] *= scale_x
        boxes[:, [1, 3]] *= scale_y
        
        # Format detections
        detections = []
        for box, score, label in zip(boxes, scores, labels):
            detections.append({
                'box': box.tolist(),
                'score': float(score),
                'label': 'Pneumonia' if label == 1 else 'Background'
            })
        
        # Visualize if output path provided
        if output_path:
            class_names = ['Background', 'Pneumonia']
            visualize_detection(
                image,
                boxes.tolist(),
                scores.tolist(),
                labels.tolist(),
                output_path,
                class_names,
                confidence_threshold
            )
        
        return detections
    
    def predict_combined(
        self,
        image_path: str,
        confidence_threshold: float = 0.5,
        output_path: str = None
    ) -> dict:
        """
        Combined classification and detection.
        
        Args:
            image_path: Path to image
            confidence_threshold: Minimum confidence for detections
            output_path: Optional path to save visualization
            
        Returns:
            Dictionary with both results
        """
        results = {}
        
        # Classification
        if self.cls_model:
            pred, conf, probs = self.predict_classification(image_path)
            results['classification'] = {
                'prediction': pred,
                'confidence': conf,
                'probabilities': probs
            }
        
        # Detection
        if self.det_model:
            detections = self.predict_detection(image_path, confidence_threshold, output_path)
            results['detection'] = {
                'num_detections': len(detections),
                'detections': detections
            }
        
        return results


def main():
    parser = argparse.ArgumentParser(description='Medical image inference')
    parser.add_argument('--image', type=str, required=True, help='Path to input image')
    parser.add_argument('--cls_model', type=str, help='Path to classification model')
    parser.add_argument('--det_model', type=str, help='Path to detection model')
    parser.add_argument('--output', type=str, help='Path to save visualization')
    parser.add_argument('--threshold', type=float, default=0.5, help='Detection confidence threshold')
    parser.add_argument('--device', type=str, default='cpu', choices=['cpu', 'cuda'])
    args = parser.parse_args()
    
    # Create predictor
    predictor = MedicalImagePredictor(
        classification_model_path=args.cls_model,
        detection_model_path=args.det_model,
        device=args.device
    )
    
    # Run prediction
    print(f"\nProcessing image: {args.image}")
    results = predictor.predict_combined(
        args.image,
        confidence_threshold=args.threshold,
        output_path=args.output
    )
    
    # Print results
    print("\n" + "="*60)
    print("PREDICTION RESULTS")
    print("="*60)
    
    if 'classification' in results:
        cls = results['classification']
        print(f"\nClassification:")
        print(f"  Prediction: {cls['prediction']}")
        print(f"  Confidence: {cls['confidence']:.4f}")
        print(f"  Probabilities:")
        for name, prob in cls['probabilities'].items():
            print(f"    {name}: {prob:.4f}")
    
    if 'detection' in results:
        det = results['detection']
        print(f"\nDetection:")
        print(f"  Number of detections: {det['num_detections']}")
        if det['num_detections'] > 0:
            print(f"  Detections:")
            for i, d in enumerate(det['detections'], 1):
                print(f"    {i}. {d['label']} (score: {d['score']:.4f})")
                print(f"       Box: {d['box']}")
    
    if args.output:
        print(f"\n✓ Visualization saved to: {args.output}")
    
    print("="*60)


if __name__ == "__main__":
    main()
