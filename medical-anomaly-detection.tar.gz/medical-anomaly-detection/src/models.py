"""
Model architectures for classification and detection.
"""
import torch
import torch.nn as nn
import torchvision
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from typing import Optional


class ChestXrayClassifier(nn.Module):
    """Classification model using transfer learning."""
    
    def __init__(
        self,
        model_name: str = 'resnet50',
        num_classes: int = 2,
        pretrained: bool = True,
        dropout: float = 0.5
    ):
        """
        Args:
            model_name: Name of backbone ('resnet50', 'efficientnet_b0', etc.)
            num_classes: Number of output classes
            pretrained: Whether to use pretrained weights
            dropout: Dropout probability
        """
        super(ChestXrayClassifier, self).__init__()
        
        self.model_name = model_name
        self.num_classes = num_classes
        
        # Load backbone
        if model_name == 'resnet50':
            self.backbone = torchvision.models.resnet50(
                weights=torchvision.models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
            )
            num_features = self.backbone.fc.in_features
            self.backbone.fc = nn.Identity()
            
        elif model_name == 'resnet34':
            self.backbone = torchvision.models.resnet34(
                weights=torchvision.models.ResNet34_Weights.IMAGENET1K_V1 if pretrained else None
            )
            num_features = self.backbone.fc.in_features
            self.backbone.fc = nn.Identity()
            
        elif model_name == 'efficientnet_b0':
            self.backbone = torchvision.models.efficientnet_b0(
                weights=torchvision.models.EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None
            )
            num_features = self.backbone.classifier[1].in_features
            self.backbone.classifier = nn.Identity()
            
        elif model_name == 'efficientnet_b3':
            self.backbone = torchvision.models.efficientnet_b3(
                weights=torchvision.models.EfficientNet_B3_Weights.IMAGENET1K_V1 if pretrained else None
            )
            num_features = self.backbone.classifier[1].in_features
            self.backbone.classifier = nn.Identity()
            
        else:
            raise ValueError(f"Unknown model: {model_name}")
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(num_features, num_classes)
        )
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass."""
        features = self.backbone(x)
        out = self.classifier(features)
        return out


class ChestXrayDetector(nn.Module):
    """Detection model using Faster R-CNN."""
    
    def __init__(
        self,
        num_classes: int = 2,  # Background + pneumonia
        backbone_name: str = 'resnet50',
        pretrained_backbone: bool = True,
        trainable_backbone_layers: int = 3,
        min_size: int = 512,
        max_size: int = 512
    ):
        """
        Args:
            num_classes: Number of classes (including background)
            backbone_name: Backbone architecture
            pretrained_backbone: Use pretrained backbone
            trainable_backbone_layers: Number of trainable backbone layers
            min_size: Min image size
            max_size: Max image size
        """
        super(ChestXrayDetector, self).__init__()
        
        # Load pretrained Faster R-CNN model
        if backbone_name == 'resnet50':
            # Start with pretrained Faster R-CNN
            self.model = torchvision.models.detection.fasterrcnn_resnet50_fpn(
                weights=torchvision.models.detection.FasterRCNN_ResNet50_FPN_Weights.DEFAULT if pretrained_backbone else None,
                trainable_backbone_layers=trainable_backbone_layers,
                min_size=min_size,
                max_size=max_size
            )
            
            # Replace the classifier head
            in_features = self.model.roi_heads.box_predictor.cls_score.in_features
            self.model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
            
        else:
            raise ValueError(f"Unknown backbone: {backbone_name}")
    
    def forward(self, images, targets=None):
        """
        Forward pass.
        
        Args:
            images: List of images
            targets: List of target dicts (for training)
        
        Returns:
            During training: dict of losses
            During inference: list of predictions
        """
        return self.model(images, targets)


def build_classification_model(
    model_name: str = 'resnet50',
    num_classes: int = 2,
    pretrained: bool = True,
    dropout: float = 0.5
) -> nn.Module:
    """Build classification model."""
    return ChestXrayClassifier(
        model_name=model_name,
        num_classes=num_classes,
        pretrained=pretrained,
        dropout=dropout
    )


def build_detection_model(
    num_classes: int = 2,
    backbone_name: str = 'resnet50',
    pretrained_backbone: bool = True,
    trainable_backbone_layers: int = 3
) -> nn.Module:
    """Build detection model."""
    detector = ChestXrayDetector(
        num_classes=num_classes,
        backbone_name=backbone_name,
        pretrained_backbone=pretrained_backbone,
        trainable_backbone_layers=trainable_backbone_layers
    )
    return detector.model


def load_model(
    checkpoint_path: str,
    model: nn.Module,
    device: torch.device = torch.device('cpu')
) -> nn.Module:
    """Load model from checkpoint."""
    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    return model


if __name__ == "__main__":
    # Test models
    print("Testing classification model...")
    cls_model = build_classification_model('resnet50', num_classes=2)
    dummy_input = torch.randn(2, 3, 224, 224)
    output = cls_model(dummy_input)
    print(f"Classification output shape: {output.shape}")
    
    print("\nTesting detection model...")
    det_model = build_detection_model(num_classes=2)
    det_model.eval()
    dummy_images = [torch.randn(3, 512, 512) for _ in range(2)]
    with torch.no_grad():
        predictions = det_model(dummy_images)
    print(f"Detection predictions: {len(predictions)} images")
    
    print("\nModels ready!")
