"""
Dataset classes for medical image classification and detection.
"""
import os
from typing import Optional, Tuple, Dict, List, Callable
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from PIL import Image
import cv2
import albumentations as A
from albumentations.pytorch import ToTensorV2


class ChestXrayClassificationDataset(Dataset):
    """Dataset for binary classification (Normal vs Pneumonia)."""
    
    def __init__(
        self,
        data_df: pd.DataFrame,
        img_dir: str,
        transform: Optional[Callable] = None,
        img_size: int = 224
    ):
        """
        Args:
            data_df: DataFrame with columns ['patientId', 'Target']
            img_dir: Directory containing image files
            transform: Albumentations transform pipeline
            img_size: Size to resize images to
        """
        self.data_df = data_df.reset_index(drop=True)
        self.img_dir = img_dir
        self.img_size = img_size
        
        # Default transform if none provided
        if transform is None:
            self.transform = self._get_default_transform()
        else:
            self.transform = transform
            
    def _get_default_transform(self) -> A.Compose:
        """Create default augmentation pipeline."""
        return A.Compose([
            A.Resize(self.img_size, self.img_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])
    
    def __len__(self) -> int:
        return len(self.data_df)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get image and label."""
        row = self.data_df.iloc[idx]
        
        # Load image
        img_path = os.path.join(self.img_dir, f"{row['patientId']}.png")
        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Apply transforms
        transformed = self.transform(image=image)
        image = transformed['image']
        
        # Get label
        label = torch.tensor(row['Target'], dtype=torch.long)
        
        return image, label


class ChestXrayDetectionDataset(Dataset):
    """Dataset for pneumonia detection with bounding boxes."""
    
    def __init__(
        self,
        data_df: pd.DataFrame,
        img_dir: str,
        transform: Optional[Callable] = None,
        img_size: int = 512
    ):
        """
        Args:
            data_df: DataFrame with columns ['patientId', 'x', 'y', 'width', 'height', 'Target']
            img_dir: Directory containing image files
            transform: Albumentations transform pipeline
            img_size: Size to resize images to
        """
        self.data_df = data_df
        self.img_dir = img_dir
        self.img_size = img_size
        
        # Group by patientId to handle multiple boxes per image
        self.patient_ids = self.data_df['patientId'].unique()
        
        if transform is None:
            self.transform = self._get_default_transform()
        else:
            self.transform = transform
    
    def _get_default_transform(self) -> A.Compose:
        """Create default augmentation pipeline for detection."""
        return A.Compose([
            A.Resize(self.img_size, self.img_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ], bbox_params=A.BboxParams(
            format='pascal_voc',
            label_fields=['labels'],
            min_visibility=0.3
        ))
    
    def __len__(self) -> int:
        return len(self.patient_ids)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, Dict]:
        """Get image and target dictionary."""
        patient_id = self.patient_ids[idx]
        
        # Load image
        img_path = os.path.join(self.img_dir, f"{patient_id}.png")
        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        orig_h, orig_w = image.shape[:2]
        
        # Get all boxes for this patient
        patient_data = self.data_df[self.data_df['patientId'] == patient_id]
        
        boxes = []
        labels = []
        
        for _, row in patient_data.iterrows():
            if row['Target'] == 1:  # Has pneumonia
                x, y, w, h = row['x'], row['y'], row['width'], row['height']
                # Convert to [xmin, ymin, xmax, ymax]
                boxes.append([x, y, x + w, y + h])
                labels.append(1)  # Pneumonia class
        
        # If no boxes (normal case), add a dummy box
        if len(boxes) == 0:
            boxes = [[0, 0, 1, 1]]
            labels = [0]  # Background class
        
        # Apply transforms
        transformed = self.transform(
            image=image,
            bboxes=boxes,
            labels=labels
        )
        
        image = transformed['image']
        boxes = transformed['bboxes']
        labels = transformed['labels']
        
        # Convert to tensors
        if len(boxes) == 0:  # If all boxes were removed by augmentation
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.int64)
        else:
            boxes = torch.as_tensor(boxes, dtype=torch.float32)
            labels = torch.as_tensor(labels, dtype=torch.int64)
        
        target = {
            'boxes': boxes,
            'labels': labels,
            'image_id': torch.tensor([idx]),
            'area': (boxes[:, 3] - boxes[:, 1]) * (boxes[:, 2] - boxes[:, 0]) if len(boxes) > 0 else torch.tensor([0.0]),
            'iscrowd': torch.zeros((len(boxes),), dtype=torch.int64)
        }
        
        return image, target


def get_classification_transforms(img_size: int = 224, is_train: bool = True) -> A.Compose:
    """Get augmentation pipeline for classification."""
    if is_train:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.HorizontalFlip(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.1,
                scale_limit=0.15,
                rotate_limit=15,
                p=0.5
            ),
            A.OneOf([
                A.GaussNoise(var_limit=(10.0, 50.0)),
                A.GaussianBlur(),
                A.MotionBlur(),
            ], p=0.3),
            A.RandomBrightnessContrast(
                brightness_limit=0.2,
                contrast_limit=0.2,
                p=0.5
            ),
            A.ElasticTransform(
                alpha=1,
                sigma=50,
                alpha_affine=50,
                p=0.3
            ),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])
    else:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ])


def get_detection_transforms(img_size: int = 512, is_train: bool = True) -> A.Compose:
    """Get augmentation pipeline for detection."""
    if is_train:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.HorizontalFlip(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.05,
                scale_limit=0.1,
                rotate_limit=10,
                p=0.5
            ),
            A.RandomBrightnessContrast(
                brightness_limit=0.15,
                contrast_limit=0.15,
                p=0.5
            ),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ], bbox_params=A.BboxParams(
            format='pascal_voc',
            label_fields=['labels'],
            min_visibility=0.3
        ))
    else:
        return A.Compose([
            A.Resize(img_size, img_size),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            ToTensorV2()
        ], bbox_params=A.BboxParams(
            format='pascal_voc',
            label_fields=['labels'],
            min_visibility=0.3
        ))


def collate_fn(batch):
    """Custom collate function for detection dataset."""
    return tuple(zip(*batch))


if __name__ == "__main__":
    # Test dataset
    print("Testing dataset classes...")
    
    # Create dummy data
    dummy_df = pd.DataFrame({
        'patientId': ['img1', 'img2', 'img3'],
        'Target': [0, 1, 1]
    })
    
    print("Dataset classes ready!")
