"""
Training script for classification and detection models.
"""
import os
import argparse
import yaml
from typing import Dict, Optional
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
from tqdm import tqdm
import wandb
from sklearn.model_selection import train_test_split

from dataset import (
    ChestXrayClassificationDataset,
    ChestXrayDetectionDataset,
    get_classification_transforms,
    get_detection_transforms,
    collate_fn
)
from models import build_classification_model, build_detection_model
from utils import (
    set_seed,
    EarlyStopping,
    AverageMeter,
    save_checkpoint,
    load_checkpoint
)


class ClassificationTrainer:
    """Trainer for classification model."""
    
    def __init__(self, config: Dict):
        self.config = config
        self.device = torch.device(config['device'])
        
        # Set seed
        set_seed(config['seed'])
        
        # Initialize model
        self.model = build_classification_model(
            model_name=config['model']['name'],
            num_classes=config['model']['num_classes'],
            pretrained=config['model']['pretrained'],
            dropout=config['model']['dropout']
        ).to(self.device)
        
        # Loss function
        if config['training']['class_weights']:
            weights = torch.tensor(config['training']['class_weights']).to(self.device)
            self.criterion = nn.CrossEntropyLoss(weight=weights)
        else:
            self.criterion = nn.CrossEntropyLoss()
        
        # Optimizer
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=config['training']['learning_rate'],
            weight_decay=config['training']['weight_decay']
        )
        
        # Scheduler
        self.scheduler = CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=config['training']['scheduler_t0'],
            T_mult=1,
            eta_min=config['training']['min_lr']
        )
        
        # Early stopping
        self.early_stopping = EarlyStopping(
            patience=config['training']['patience'],
            mode='max',
            delta=config['training']['min_delta']
        )
        
        # Metrics tracking
        self.best_val_auc = 0.0
        self.epoch = 0
        
        # WandB
        if config['logging']['use_wandb']:
            wandb.init(
                project=config['logging']['project_name'],
                name=config['logging']['run_name'],
                config=config
            )
    
    def train_epoch(self, train_loader: DataLoader) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        
        loss_meter = AverageMeter()
        acc_meter = AverageMeter()
        
        pbar = tqdm(train_loader, desc=f"Epoch {self.epoch+1} [Train]")
        
        for batch_idx, (images, labels) in enumerate(pbar):
            images = images.to(self.device)
            labels = labels.to(self.device)
            
            # Forward pass
            outputs = self.model(images)
            loss = self.criterion(outputs, labels)
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            if self.config['training']['gradient_clip_val'] > 0:
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.config['training']['gradient_clip_val']
                )
            
            self.optimizer.step()
            
            # Calculate accuracy
            _, preds = torch.max(outputs, 1)
            acc = (preds == labels).float().mean()
            
            # Update meters
            loss_meter.update(loss.item(), images.size(0))
            acc_meter.update(acc.item(), images.size(0))
            
            # Update progress bar
            pbar.set_postfix({
                'loss': f'{loss_meter.avg:.4f}',
                'acc': f'{acc_meter.avg:.4f}'
            })
        
        return {
            'train_loss': loss_meter.avg,
            'train_acc': acc_meter.avg
        }
    
    def validate(self, val_loader: DataLoader) -> Dict[str, float]:
        """Validate model."""
        self.model.eval()
        
        loss_meter = AverageMeter()
        acc_meter = AverageMeter()
        
        all_preds = []
        all_labels = []
        all_probs = []
        
        with torch.no_grad():
            pbar = tqdm(val_loader, desc=f"Epoch {self.epoch+1} [Val]")
            
            for images, labels in pbar:
                images = images.to(self.device)
                labels = labels.to(self.device)
                
                # Forward pass
                outputs = self.model(images)
                loss = self.criterion(outputs, labels)
                
                # Calculate accuracy
                probs = torch.softmax(outputs, dim=1)
                _, preds = torch.max(outputs, 1)
                acc = (preds == labels).float().mean()
                
                # Update meters
                loss_meter.update(loss.item(), images.size(0))
                acc_meter.update(acc.item(), images.size(0))
                
                # Store predictions
                all_preds.extend(preds.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                all_probs.extend(probs[:, 1].cpu().numpy())  # Probability of positive class
                
                pbar.set_postfix({
                    'loss': f'{loss_meter.avg:.4f}',
                    'acc': f'{acc_meter.avg:.4f}'
                })
        
        # Calculate AUC
        from sklearn.metrics import roc_auc_score
        val_auc = roc_auc_score(all_labels, all_probs)
        
        return {
            'val_loss': loss_meter.avg,
            'val_acc': acc_meter.avg,
            'val_auc': val_auc,
            'predictions': all_preds,
            'labels': all_labels,
            'probs': all_probs
        }
    
    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        """Full training loop."""
        print(f"Starting training for {self.config['training']['epochs']} epochs...")
        
        for epoch in range(self.config['training']['epochs']):
            self.epoch = epoch
            
            # Train
            train_metrics = self.train_epoch(train_loader)
            
            # Validate
            val_metrics = self.validate(val_loader)
            
            # Scheduler step
            self.scheduler.step()
            
            # Log metrics
            metrics = {**train_metrics, **val_metrics, 'epoch': epoch, 'lr': self.optimizer.param_groups[0]['lr']}
            
            if self.config['logging']['use_wandb']:
                wandb.log(metrics)
            
            print(f"\nEpoch {epoch+1}/{self.config['training']['epochs']}")
            print(f"Train Loss: {train_metrics['train_loss']:.4f}, Train Acc: {train_metrics['train_acc']:.4f}")
            print(f"Val Loss: {val_metrics['val_loss']:.4f}, Val Acc: {val_metrics['val_acc']:.4f}, Val AUC: {val_metrics['val_auc']:.4f}")
            
            # Save best model
            if val_metrics['val_auc'] > self.best_val_auc:
                self.best_val_auc = val_metrics['val_auc']
                save_checkpoint(
                    self.model,
                    self.optimizer,
                    epoch,
                    val_metrics['val_auc'],
                    os.path.join(self.config['output_dir'], 'best_model.pth')
                )
                print(f"✓ Saved best model (AUC: {val_metrics['val_auc']:.4f})")
            
            # Early stopping
            self.early_stopping(val_metrics['val_auc'])
            if self.early_stopping.early_stop:
                print(f"\nEarly stopping triggered at epoch {epoch+1}")
                break
            
            # Save checkpoint
            if (epoch + 1) % self.config['training']['save_freq'] == 0:
                save_checkpoint(
                    self.model,
                    self.optimizer,
                    epoch,
                    val_metrics['val_auc'],
                    os.path.join(self.config['output_dir'], f'checkpoint_epoch_{epoch+1}.pth')
                )
        
        print(f"\nTraining complete! Best Val AUC: {self.best_val_auc:.4f}")


class DetectionTrainer:
    """Trainer for detection model."""
    
    def __init__(self, config: Dict):
        self.config = config
        self.device = torch.device(config['device'])
        
        # Set seed
        set_seed(config['seed'])
        
        # Initialize model
        self.model = build_detection_model(
            num_classes=config['model']['num_classes'],
            backbone_name=config['model']['backbone'],
            pretrained_backbone=config['model']['pretrained'],
            trainable_backbone_layers=config['model']['trainable_layers']
        ).to(self.device)
        
        # Optimizer
        params = [p for p in self.model.parameters() if p.requires_grad]
        self.optimizer = AdamW(
            params,
            lr=config['training']['learning_rate'],
            weight_decay=config['training']['weight_decay']
        )
        
        # Scheduler
        self.scheduler = CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=config['training']['scheduler_t0'],
            T_mult=1,
            eta_min=config['training']['min_lr']
        )
        
        self.epoch = 0
        self.best_val_loss = float('inf')
        
        # WandB
        if config['logging']['use_wandb']:
            wandb.init(
                project=config['logging']['project_name'],
                name=config['logging']['run_name'],
                config=config
            )
    
    def train_epoch(self, train_loader: DataLoader) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        
        loss_meter = AverageMeter()
        
        pbar = tqdm(train_loader, desc=f"Epoch {self.epoch+1} [Train]")
        
        for images, targets in pbar:
            images = [img.to(self.device) for img in images]
            targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
            
            # Forward pass
            loss_dict = self.model(images, targets)
            losses = sum(loss for loss in loss_dict.values())
            
            # Backward pass
            self.optimizer.zero_grad()
            losses.backward()
            
            if self.config['training']['gradient_clip_val'] > 0:
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.config['training']['gradient_clip_val']
                )
            
            self.optimizer.step()
            
            # Update meter
            loss_meter.update(losses.item(), len(images))
            
            pbar.set_postfix({'loss': f'{loss_meter.avg:.4f}'})
        
        return {'train_loss': loss_meter.avg}
    
    def validate(self, val_loader: DataLoader) -> Dict[str, float]:
        """Validate model."""
        self.model.train()  # Keep in train mode to get losses
        
        loss_meter = AverageMeter()
        
        with torch.no_grad():
            pbar = tqdm(val_loader, desc=f"Epoch {self.epoch+1} [Val]")
            
            for images, targets in pbar:
                images = [img.to(self.device) for img in images]
                targets = [{k: v.to(self.device) for k, v in t.items()} for t in targets]
                
                loss_dict = self.model(images, targets)
                losses = sum(loss for loss in loss_dict.values())
                
                loss_meter.update(losses.item(), len(images))
                
                pbar.set_postfix({'loss': f'{loss_meter.avg:.4f}'})
        
        return {'val_loss': loss_meter.avg}
    
    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        """Full training loop."""
        print(f"Starting detection training for {self.config['training']['epochs']} epochs...")
        
        for epoch in range(self.config['training']['epochs']):
            self.epoch = epoch
            
            train_metrics = self.train_epoch(train_loader)
            val_metrics = self.validate(val_loader)
            
            self.scheduler.step()
            
            metrics = {**train_metrics, **val_metrics, 'epoch': epoch, 'lr': self.optimizer.param_groups[0]['lr']}
            
            if self.config['logging']['use_wandb']:
                wandb.log(metrics)
            
            print(f"\nEpoch {epoch+1}/{self.config['training']['epochs']}")
            print(f"Train Loss: {train_metrics['train_loss']:.4f}, Val Loss: {val_metrics['val_loss']:.4f}")
            
            # Save best model
            if val_metrics['val_loss'] < self.best_val_loss:
                self.best_val_loss = val_metrics['val_loss']
                save_checkpoint(
                    self.model,
                    self.optimizer,
                    epoch,
                    val_metrics['val_loss'],
                    os.path.join(self.config['output_dir'], 'best_detection_model.pth')
                )
                print(f"✓ Saved best model (Loss: {val_metrics['val_loss']:.4f})")
        
        print(f"\nTraining complete! Best Val Loss: {self.best_val_loss:.4f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True, help='Path to config file')
    parser.add_argument('--phase', type=str, choices=['classification', 'detection'], required=True)
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Create output directory
    os.makedirs(config['output_dir'], exist_ok=True)
    
    # Load data
    print("Loading data...")
    # This is a placeholder - replace with actual data loading
    # train_df = pd.read_csv(config['data']['train_csv'])
    # etc.
    
    print(f"Starting {args.phase} training...")


if __name__ == "__main__":
    main()
