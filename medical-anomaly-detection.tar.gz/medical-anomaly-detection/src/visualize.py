"""
Visualization functions for results and predictions.
"""
import os
from typing import List, Optional
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, precision_recall_curve
import cv2
import torch


def plot_roc_curve(
    labels: np.ndarray,
    probabilities: np.ndarray,
    output_dir: str,
    figsize: tuple = (10, 8)
):
    """Plot ROC curve."""
    fpr, tpr, thresholds = roc_curve(labels, probabilities)
    
    from sklearn.metrics import roc_auc_score
    auc = roc_auc_score(labels, probabilities)
    
    plt.figure(figsize=figsize)
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {auc:.4f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('Receiver Operating Characteristic (ROC) Curve', fontsize=14, fontweight='bold')
    plt.legend(loc="lower right", fontsize=11)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, 'roc_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()


def plot_pr_curve(
    labels: np.ndarray,
    probabilities: np.ndarray,
    output_dir: str,
    figsize: tuple = (10, 8)
):
    """Plot Precision-Recall curve."""
    precision, recall, thresholds = precision_recall_curve(labels, probabilities)
    
    from sklearn.metrics import average_precision_score
    ap = average_precision_score(labels, probabilities)
    
    plt.figure(figsize=figsize)
    plt.plot(recall, precision, color='darkorange', lw=2, label=f'PR curve (AP = {ap:.4f})')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title('Precision-Recall Curve', fontsize=14, fontweight='bold')
    plt.legend(loc="lower left", fontsize=11)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, 'pr_curve.png'), dpi=300, bbox_inches='tight')
    plt.close()


def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: List[str],
    output_dir: str,
    figsize: tuple = (10, 8)
):
    """Plot confusion matrix."""
    plt.figure(figsize=figsize)
    
    # Normalize
    cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    
    # Plot
    sns.heatmap(
        cm_norm,
        annot=True,
        fmt='.2%',
        cmap='Blues',
        xticklabels=class_names,
        yticklabels=class_names,
        cbar_kws={'label': 'Proportion'},
        square=True,
        linewidths=1,
        linecolor='gray'
    )
    
    # Add raw counts as text
    for i in range(len(class_names)):
        for j in range(len(class_names)):
            plt.text(j + 0.5, i + 0.7, f'({cm[i, j]})',
                    ha='center', va='center', fontsize=10, color='gray')
    
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.title('Confusion Matrix', fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, 'confusion_matrix.png'), dpi=300, bbox_inches='tight')
    plt.close()


def plot_sample_predictions(
    images: List[np.ndarray],
    predictions: List[int],
    probabilities: List[float],
    labels: List[int],
    output_dir: str,
    class_names: List[str] = ['Normal', 'Pneumonia'],
    n_samples: int = 16,
    figsize: tuple = (20, 20)
):
    """Plot sample predictions in a grid."""
    n_samples = min(n_samples, len(images))
    n_cols = 4
    n_rows = (n_samples + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
    axes = axes.flatten()
    
    for idx in range(n_samples):
        ax = axes[idx]
        
        # Display image
        img = images[idx]
        if img.shape[0] == 3:  # CHW format
            img = np.transpose(img, (1, 2, 0))
        
        ax.imshow(img, cmap='gray')
        ax.axis('off')
        
        # Create title
        pred_label = class_names[predictions[idx]]
        true_label = class_names[labels[idx]]
        confidence = probabilities[idx]
        
        # Color code: green for correct, red for incorrect
        color = 'green' if predictions[idx] == labels[idx] else 'red'
        
        title = f'Pred: {pred_label} ({confidence:.2%})\nTrue: {true_label}'
        ax.set_title(title, fontsize=10, color=color, fontweight='bold')
    
    # Hide empty subplots
    for idx in range(n_samples, len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'sample_predictions.png'), dpi=300, bbox_inches='tight')
    plt.close()


def visualize_detection(
    image: np.ndarray,
    boxes: List[List[float]],
    scores: List[float],
    labels: List[int],
    output_path: Optional[str] = None,
    class_names: List[str] = ['Background', 'Pneumonia'],
    score_threshold: float = 0.5
) -> np.ndarray:
    """
    Visualize detection results with bounding boxes.
    
    Args:
        image: Input image (H, W, 3)
        boxes: List of bounding boxes [xmin, ymin, xmax, ymax]
        scores: Confidence scores
        labels: Class labels
        output_path: Path to save visualization
        class_names: List of class names
        score_threshold: Minimum confidence to display
        
    Returns:
        Annotated image
    """
    # Make a copy
    vis_image = image.copy()
    
    # Draw boxes
    for box, score, label in zip(boxes, scores, labels):
        if score < score_threshold:
            continue
        
        xmin, ymin, xmax, ymax = map(int, box)
        
        # Draw rectangle
        color = (0, 255, 0) if label == 1 else (255, 0, 0)
        cv2.rectangle(vis_image, (xmin, ymin), (xmax, ymax), color, 2)
        
        # Draw label
        label_text = f'{class_names[label]}: {score:.2f}'
        (text_width, text_height), _ = cv2.getTextSize(
            label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2
        )
        
        cv2.rectangle(
            vis_image,
            (xmin, ymin - text_height - 10),
            (xmin + text_width, ymin),
            color,
            -1
        )
        
        cv2.putText(
            vis_image,
            label_text,
            (xmin, ymin - 5),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )
    
    if output_path:
        cv2.imwrite(output_path, vis_image)
    
    return vis_image


def plot_training_history(
    history: dict,
    output_dir: str,
    figsize: tuple = (15, 5)
):
    """Plot training history."""
    fig, axes = plt.subplots(1, 3, figsize=figsize)
    
    # Loss
    axes[0].plot(history['train_loss'], label='Train Loss')
    axes[0].plot(history['val_loss'], label='Val Loss')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Loss')
    axes[0].set_title('Training and Validation Loss')
    axes[0].legend()
    axes[0].grid(alpha=0.3)
    
    # Accuracy
    axes[1].plot(history['train_acc'], label='Train Acc')
    axes[1].plot(history['val_acc'], label='Val Acc')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Accuracy')
    axes[1].set_title('Training and Validation Accuracy')
    axes[1].legend()
    axes[1].grid(alpha=0.3)
    
    # Learning rate
    axes[2].plot(history['lr'])
    axes[2].set_xlabel('Epoch')
    axes[2].set_ylabel('Learning Rate')
    axes[2].set_title('Learning Rate Schedule')
    axes[2].set_yscale('log')
    axes[2].grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'training_history.png'), dpi=300, bbox_inches='tight')
    plt.close()


def create_heatmap(
    model: torch.nn.Module,
    image: torch.Tensor,
    device: torch.device
) -> np.ndarray:
    """
    Create a simple activation heatmap (Grad-CAM style).
    
    Args:
        model: Trained model
        image: Input image tensor
        device: Device to run on
        
    Returns:
        Heatmap as numpy array
    """
    # This is a simplified version
    # For production, use libraries like pytorch-grad-cam
    
    model.eval()
    image = image.unsqueeze(0).to(device)
    
    # Forward pass
    with torch.no_grad():
        output = model(image)
        probs = torch.softmax(output, dim=1)
    
    # For now, return a placeholder
    # In production, implement proper Grad-CAM
    heatmap = np.random.rand(224, 224)
    
    return heatmap
