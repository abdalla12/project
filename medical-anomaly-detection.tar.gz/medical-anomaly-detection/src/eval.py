"""
Evaluation script with comprehensive metrics and visualizations.
"""
import os
import argparse
import yaml
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import (
    roc_auc_score,
    roc_curve,
    precision_recall_curve,
    average_precision_score,
    confusion_matrix,
    classification_report,
    f1_score
)
import matplotlib.pyplot as plt
import seaborn as sns

from dataset import ChestXrayClassificationDataset, get_classification_transforms
from models import build_classification_model, load_model
from visualize import (
    plot_roc_curve,
    plot_pr_curve,
    plot_confusion_matrix,
    plot_sample_predictions
)


class ClassificationEvaluator:
    """Evaluator for classification model."""
    
    def __init__(self, config: Dict, model_path: str):
        self.config = config
        self.device = torch.device(config['device'])
        
        # Load model
        print("Loading model...")
        self.model = build_classification_model(
            model_name=config['model']['name'],
            num_classes=config['model']['num_classes'],
            pretrained=False
        )
        self.model = load_model(model_path, self.model, self.device)
        self.model.eval()
        
        print(f"Model loaded from {model_path}")
    
    def predict(self, dataloader: DataLoader) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Get predictions for all samples.
        
        Returns:
            predictions: Predicted class labels
            probabilities: Predicted probabilities for positive class
            labels: True labels
        """
        all_preds = []
        all_probs = []
        all_labels = []
        
        with torch.no_grad():
            for images, labels in dataloader:
                images = images.to(self.device)
                
                outputs = self.model(images)
                probs = torch.softmax(outputs, dim=1)
                preds = torch.argmax(outputs, dim=1)
                
                all_preds.extend(preds.cpu().numpy())
                all_probs.extend(probs[:, 1].cpu().numpy())
                all_labels.extend(labels.numpy())
        
        return (
            np.array(all_preds),
            np.array(all_probs),
            np.array(all_labels)
        )
    
    def evaluate(self, dataloader: DataLoader, output_dir: str):
        """
        Comprehensive evaluation with metrics and visualizations.
        
        Args:
            dataloader: DataLoader for test set
            output_dir: Directory to save results
        """
        print("Running evaluation...")
        os.makedirs(output_dir, exist_ok=True)
        
        # Get predictions
        predictions, probabilities, labels = self.predict(dataloader)
        
        # Calculate metrics
        print("\n" + "="*50)
        print("EVALUATION METRICS")
        print("="*50)
        
        # ROC AUC
        auc = roc_auc_score(labels, probabilities)
        print(f"\nAUC-ROC: {auc:.4f}")
        
        # Average Precision
        ap = average_precision_score(labels, probabilities)
        print(f"Average Precision: {ap:.4f}")
        
        # Classification Report
        print("\nClassification Report:")
        print(classification_report(
            labels,
            predictions,
            target_names=['Normal', 'Pneumonia'],
            digits=4
        ))
        
        # Confusion Matrix
        cm = confusion_matrix(labels, predictions)
        tn, fp, fn, tp = cm.ravel()
        
        # Calculate additional metrics
        sensitivity = tp / (tp + fn)  # Recall
        specificity = tn / (tn + fp)
        precision = tp / (tp + fp)
        f1 = f1_score(labels, predictions)
        accuracy = (tp + tn) / (tp + tn + fp + fn)
        
        print("\nDetailed Metrics:")
        print(f"Sensitivity (Recall): {sensitivity:.4f}")
        print(f"Specificity: {specificity:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"F1 Score: {f1:.4f}")
        print(f"Accuracy: {accuracy:.4f}")
        
        # Save metrics to file
        metrics = {
            'auc_roc': float(auc),
            'average_precision': float(ap),
            'sensitivity': float(sensitivity),
            'specificity': float(specificity),
            'precision': float(precision),
            'f1_score': float(f1),
            'accuracy': float(accuracy),
            'confusion_matrix': cm.tolist()
        }
        
        with open(os.path.join(output_dir, 'metrics.yaml'), 'w') as f:
            yaml.dump(metrics, f)
        
        # Plot ROC curve
        print("\nGenerating visualizations...")
        plot_roc_curve(labels, probabilities, output_dir)
        
        # Plot PR curve
        plot_pr_curve(labels, probabilities, output_dir)
        
        # Plot confusion matrix
        plot_confusion_matrix(cm, ['Normal', 'Pneumonia'], output_dir)
        
        # Error analysis
        self.error_analysis(predictions, probabilities, labels, dataloader, output_dir)
        
        print(f"\nResults saved to {output_dir}")
        print("="*50)
    
    def error_analysis(
        self,
        predictions: np.ndarray,
        probabilities: np.ndarray,
        labels: np.ndarray,
        dataloader: DataLoader,
        output_dir: str,
        n_samples: int = 10
    ):
        """
        Analyze and visualize errors.
        
        Args:
            predictions: Predicted labels
            probabilities: Predicted probabilities
            labels: True labels
            dataloader: DataLoader (needed for images)
            output_dir: Directory to save results
            n_samples: Number of samples to visualize
        """
        print("\nPerforming error analysis...")
        
        # Find false positives and false negatives
        fp_indices = np.where((predictions == 1) & (labels == 0))[0]
        fn_indices = np.where((predictions == 0) & (labels == 1))[0]
        
        print(f"False Positives: {len(fp_indices)}")
        print(f"False Negatives: {len(fn_indices)}")
        
        # Sort by confidence
        fp_confidences = probabilities[fp_indices]
        fn_confidences = 1 - probabilities[fn_indices]
        
        # Get top confident errors
        top_fp = fp_indices[np.argsort(fp_confidences)[-n_samples:]]
        top_fn = fn_indices[np.argsort(fn_confidences)[-n_samples:]]
        
        # Save error indices
        error_data = {
            'false_positives': {
                'indices': fp_indices.tolist(),
                'confidences': fp_confidences.tolist()
            },
            'false_negatives': {
                'indices': fn_indices.tolist(),
                'confidences': fn_confidences.tolist()
            }
        }
        
        with open(os.path.join(output_dir, 'errors.yaml'), 'w') as f:
            yaml.dump(error_data, f)
        
        print(f"Top {n_samples} most confident errors identified")
        print(f"Error analysis saved to {output_dir}/errors.yaml")


def main():
    parser = argparse.ArgumentParser(description='Evaluate classification model')
    parser.add_argument('--config', type=str, required=True, help='Path to config file')
    parser.add_argument('--model_path', type=str, required=True, help='Path to model checkpoint')
    parser.add_argument('--output_dir', type=str, default='./experiments/evaluation', help='Output directory')
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Create evaluator
    evaluator = ClassificationEvaluator(config, args.model_path)
    
    # Load test data
    print("Loading test data...")
    # Placeholder - replace with actual data loading
    # test_df = pd.read_csv(config['data']['test_csv'])
    # test_dataset = ChestXrayClassificationDataset(...)
    # test_loader = DataLoader(...)
    
    # Run evaluation
    # evaluator.evaluate(test_loader, args.output_dir)
    
    print("Evaluation complete!")


if __name__ == "__main__":
    main()
