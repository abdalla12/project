"""
Data preprocessing: DICOM to PNG conversion and train/val/test split.
"""
import os
import argparse
from pathlib import Path
from typing import Tuple
import numpy as np
import pandas as pd
import pydicom
from PIL import Image
import cv2
from tqdm import tqdm
from sklearn.model_selection import train_test_split


def apply_windowing(dicom_array: np.ndarray, window_center: int = 600, window_width: int = 1500) -> np.ndarray:
    """
    Apply windowing (contrast adjustment) to DICOM image.
    
    Args:
        dicom_array: Raw DICOM pixel array
        window_center: Window center (L)
        window_width: Window width (W)
    
    Returns:
        Windowed array normalized to [0, 255]
    """
    img_min = window_center - window_width // 2
    img_max = window_center + window_width // 2
    
    windowed = np.clip(dicom_array, img_min, img_max)
    windowed = ((windowed - img_min) / (img_max - img_min) * 255.0).astype(np.uint8)
    
    return windowed


def dicom_to_png(
    dicom_path: str,
    output_path: str,
    apply_lung_window: bool = True,
    size: Tuple[int, int] = None
):
    """
    Convert DICOM file to PNG.
    
    Args:
        dicom_path: Path to DICOM file
        output_path: Output PNG path
        apply_lung_window: Whether to apply lung windowing
        size: Optional resize dimensions (width, height)
    """
    # Read DICOM
    dicom = pydicom.dcmread(dicom_path)
    image = dicom.pixel_array
    
    # Apply windowing for better visualization
    if apply_lung_window:
        image = apply_windowing(image, window_center=600, window_width=1500)
    else:
        # Simple normalization
        image = ((image - image.min()) / (image.max() - image.min()) * 255.0).astype(np.uint8)
    
    # Convert to RGB
    image_rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    
    # Resize if specified
    if size:
        image_rgb = cv2.resize(image_rgb, size, interpolation=cv2.INTER_AREA)
    
    # Save as PNG
    cv2.imwrite(output_path, image_rgb)


def process_rsna_dataset(
    data_dir: str,
    output_dir: str,
    labels_csv: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 42
):
    """
    Process RSNA Pneumonia Detection dataset.
    
    Args:
        data_dir: Directory containing stage_2_train_images/
        output_dir: Output directory for processed data
        labels_csv: Path to stage_2_train_labels.csv
        train_ratio: Training set ratio
        val_ratio: Validation set ratio
        test_ratio: Test set ratio
        seed: Random seed
    """
    print("="*60)
    print("RSNA Pneumonia Detection Dataset Preprocessing")
    print("="*60)
    
    # Verify ratios
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "Ratios must sum to 1.0"
    
    # Create output directories
    output_dir = Path(output_dir)
    train_dir = output_dir / 'train'
    val_dir = output_dir / 'val'
    test_dir = output_dir / 'test'
    
    for directory in [train_dir, val_dir, test_dir]:
        directory.mkdir(parents=True, exist_ok=True)
    
    # Load labels
    print("\nLoading labels...")
    labels_df = pd.read_csv(labels_csv)
    print(f"Total samples: {len(labels_df)}")
    
    # Handle multiple boxes per image - aggregate to patient level
    # For classification: if any box exists, mark as positive
    patient_labels = labels_df.groupby('patientId').agg({
        'Target': 'max'  # 1 if any box present
    }).reset_index()
    
    print(f"Unique patients: {len(patient_labels)}")
    print(f"Normal: {(patient_labels['Target'] == 0).sum()}")
    print(f"Pneumonia: {(patient_labels['Target'] == 1).sum()}")
    
    # Stratified split
    print("\nPerforming stratified train/val/test split...")
    
    # First split: train + val vs test
    train_val_df, test_df = train_test_split(
        patient_labels,
        test_size=test_ratio,
        stratify=patient_labels['Target'],
        random_state=seed
    )
    
    # Second split: train vs val
    relative_val_ratio = val_ratio / (train_ratio + val_ratio)
    train_df, val_df = train_test_split(
        train_val_df,
        test_size=relative_val_ratio,
        stratify=train_val_df['Target'],
        random_state=seed
    )
    
    print(f"\nTrain: {len(train_df)} ({len(train_df)/len(patient_labels)*100:.1f}%)")
    print(f"Val: {len(val_df)} ({len(val_df)/len(patient_labels)*100:.1f}%)")
    print(f"Test: {len(test_df)} ({len(test_df)/len(patient_labels)*100:.1f}%)")
    
    # Convert DICOM to PNG
    print("\nConverting DICOM to PNG...")
    dicom_dir = Path(data_dir) / 'stage_2_train_images'
    
    def process_split(df, split_dir, split_name):
        print(f"\nProcessing {split_name} set...")
        for _, row in tqdm(df.iterrows(), total=len(df), desc=split_name):
            patient_id = row['patientId']
            dicom_path = dicom_dir / f'{patient_id}.dcm'
            png_path = split_dir / f'{patient_id}.png'
            
            if dicom_path.exists():
                try:
                    dicom_to_png(str(dicom_path), str(png_path), apply_lung_window=True)
                except Exception as e:
                    print(f"\nError processing {patient_id}: {e}")
    
    process_split(train_df, train_dir, 'train')
    process_split(val_df, val_dir, 'val')
    process_split(test_df, test_dir, 'test')
    
    # Save split CSVs
    print("\nSaving split metadata...")
    train_df.to_csv(output_dir / 'train.csv', index=False)
    val_df.to_csv(output_dir / 'val.csv', index=False)
    test_df.to_csv(output_dir / 'test.csv', index=False)
    
    # For detection task, also save bounding box information
    print("\nPreparing detection annotations...")
    
    # Filter labels_df to only include samples in each split
    train_boxes = labels_df[labels_df['patientId'].isin(train_df['patientId'])]
    val_boxes = labels_df[labels_df['patientId'].isin(val_df['patientId'])]
    test_boxes = labels_df[labels_df['patientId'].isin(test_df['patientId'])]
    
    train_boxes.to_csv(output_dir / 'train_boxes.csv', index=False)
    val_boxes.to_csv(output_dir / 'val_boxes.csv', index=False)
    test_boxes.to_csv(output_dir / 'test_boxes.csv', index=False)
    
    # Summary
    print("\n" + "="*60)
    print("Preprocessing Complete!")
    print("="*60)
    print(f"\nOutput directory: {output_dir}")
    print(f"Train images: {len(train_df)}")
    print(f"Val images: {len(val_df)}")
    print(f"Test images: {len(test_df)}")
    print("\nFiles saved:")
    print("  - train/val/test directories with PNG images")
    print("  - train/val/test.csv with classification labels")
    print("  - train/val/test_boxes.csv with detection annotations")
    print("="*60)


def main():
    parser = argparse.ArgumentParser(description='Preprocess RSNA Pneumonia Detection dataset')
    parser.add_argument(
        '--data_dir',
        type=str,
        required=True,
        help='Directory containing stage_2_train_images/'
    )
    parser.add_argument(
        '--output_dir',
        type=str,
        required=True,
        help='Output directory for processed data'
    )
    parser.add_argument(
        '--labels_csv',
        type=str,
        required=True,
        help='Path to stage_2_train_labels.csv'
    )
    parser.add_argument(
        '--train_ratio',
        type=float,
        default=0.7,
        help='Training set ratio'
    )
    parser.add_argument(
        '--val_ratio',
        type=float,
        default=0.15,
        help='Validation set ratio'
    )
    parser.add_argument(
        '--test_ratio',
        type=float,
        default=0.15,
        help='Test set ratio'
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=42,
        help='Random seed'
    )
    
    args = parser.parse_args()
    
    process_rsna_dataset(
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        labels_csv=args.labels_csv,
        train_ratio=args.train_ratio,
        val_ratio=args.val_ratio,
        test_ratio=args.test_ratio,
        seed=args.seed
    )


if __name__ == "__main__":
    main()
