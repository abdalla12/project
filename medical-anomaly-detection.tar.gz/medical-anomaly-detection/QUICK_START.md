# Quick Start Guide

Get up and running in 5 minutes!

## Prerequisites

- Python 3.9+
- 8GB+ RAM
- (Optional) NVIDIA GPU with CUDA

## Installation

```bash
# 1. Clone repository
git clone https://github.com/yourusername/medical-anomaly-detection.git
cd medical-anomaly-detection

# 2. Create environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

## Download Sample Data

```bash
# Option 1: Full RSNA dataset (requires Kaggle API)
kaggle competitions download -c rsna-pneumonia-detection-challenge

# Option 2: Sample subset for testing (coming soon)
# wget https://example.com/sample_data.zip
```

## Run Quick Demo

### 1. Preprocess Data (5-10 minutes)

```bash
python src/preprocess.py \
    --data_dir ./data/raw \
    --output_dir ./data/processed \
    --labels_csv ./data/raw/stage_2_train_labels.csv
```

### 2. Train Classification Model (30-60 minutes on GPU)

```bash
# Quick training with default settings
python src/train.py \
    --config configs/classification.yaml \
    --phase classification
```

**Quick config for testing (edit configs/classification.yaml):**
```yaml
training:
  epochs: 5  # Reduce from 50 for quick test
  batch_size: 16
```

### 3. Evaluate Model

```bash
python src/eval.py \
    --config configs/classification.yaml \
    --model_path ./experiments/classification/best_model.pth \
    --output_dir ./experiments/evaluation
```

### 4. Test Inference

```bash
# Download a test X-ray or use one from your dataset
python src/infer.py \
    --image ./data/processed/test/sample_image.png \
    --cls_model ./experiments/classification/best_model.pth \
    --device cpu
```

### 5. Start API Server

```bash
# Terminal 1: Start server
uvicorn api.main:app --reload

# Terminal 2: Test endpoint
curl -X POST "http://localhost:8000/predict/classification" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "file=@test_xray.png"
```

## Expected Timeline

- **Data preprocessing**: 5-10 minutes
- **Classification training** (full): 1-2 hours on GPU
- **Detection training** (full): 2-3 hours on GPU
- **Evaluation**: 5-10 minutes
- **API deployment**: Instant

## Quick Results Preview

After training classification model for 5 epochs (quick test):
```
Epoch 5/5
Train Loss: 0.3421, Train Acc: 0.8456
Val Loss: 0.3892, Val Acc: 0.8234, Val AUC: 0.8912
```

After full training (50 epochs):
```
Best Val AUC: 0.9234
Sensitivity: 0.9123
Specificity: 0.8867
```

## Common Quick Issues

**Out of Memory?**
```yaml
# Reduce batch size in config
training:
  batch_size: 8  # or even 4
```

**Slow training?**
```python
# Check if CUDA is available
import torch
print(f"CUDA: {torch.cuda.is_available()}")
```

**Import errors?**
```bash
pip install -e .
```

## Next Steps

1. ✅ Got it working? See [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md) for full details
2. 🚀 Deploy to production? See [docker/](docker/)
3. 📊 Experiment tracking? Setup [Weights & Biases](https://wandb.ai)
4. 🔧 Customize? Edit configs in [configs/](configs/)

## Need Help?

- 📖 Full docs: [README.md](README.md)
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/medical-anomaly-detection/issues)
- 💬 Questions: your.email@example.com

---

**Tip**: Start with classification (Phase A) before moving to detection (Phase B). Detection is more complex and builds on classification success!
