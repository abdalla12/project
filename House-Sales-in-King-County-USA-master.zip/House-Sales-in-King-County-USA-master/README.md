# House-Sales-in-King-County-USA
Assignment solution for Data Analysis with Python course on Coursera.
Try to solve assignment by yourself, this code is only for reference and intended to help.
